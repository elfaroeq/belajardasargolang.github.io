package main

import "fmt"

func main() {
	defer fmt.Println("halo")
	fmt.Println("selamat datang")
}
