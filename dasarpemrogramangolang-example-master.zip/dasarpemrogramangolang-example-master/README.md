# Dasar Pemrograman Golang

Source Code Praktek E-book [Dasar Pemrograman Golang](https://dasarpemrogramangolang.novalagung.com).

## Lisensi

GNU LGPL v2.1
