# Implementasi Session yang lebih Advance

Bagian ini sebenarnya ingin saya bahas di buku, tapi setelah beberapa pertimbangan lebih baik tidak, hehe. Anyway, silakan lihat source code nya jika berminat.