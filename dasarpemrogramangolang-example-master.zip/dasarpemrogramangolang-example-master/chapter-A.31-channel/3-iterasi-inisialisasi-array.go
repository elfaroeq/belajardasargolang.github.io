package main

import "fmt"

func main() {
	for _, each := range []string{"wick", "hunt", "bourne"} {
		fmt.Println(each)
	}
}
