package main

import "fmt"

func main() {
	var i = 0

	for i < 5 {
		fmt.Println("Angka", i)
		i++
	}
}
