package main

import "fmt"
import "strconv"

func main() {
	var num = 124
	var str = strconv.Itoa(num)

	fmt.Println(str) // "124"
}
