package library

type Student struct {
	Name  string
	Grade int
}
