package main

import "belajar-golang-level-akses-say-hello/library"

func main() {
	library.SayHello("ethan")
}
