package main

import "fmt"

func sayHello(name string) {
	fmt.Println("halo", name)
}
