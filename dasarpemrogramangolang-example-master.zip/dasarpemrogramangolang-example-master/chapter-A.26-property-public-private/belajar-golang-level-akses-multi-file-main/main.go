package main

func main() {
	sayHello("ethan")
}
