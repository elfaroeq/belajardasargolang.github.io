package main

import "fmt"

func main() {
	var fruits = [4]string{
		"apple",
		"grape",
		"banana",
		"melon",
	}

	fmt.Println(fruits)
}
