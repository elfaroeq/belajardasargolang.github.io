package main

import "fmt"
import "strings"

func main() {
	var str = strings.Repeat("na", 4)
	fmt.Println(str)
}
