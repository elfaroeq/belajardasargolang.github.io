package main

import "fmt"
import "strings"

func main() {
	var str = strings.ToLower("aLAy")
	fmt.Println(str)
}
