package main

import "fmt"
import "strings"

func main() {
	var str = strings.ToUpper("eat!")
	fmt.Println(str)
}
