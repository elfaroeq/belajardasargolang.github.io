package main

import "fmt"

func main() {
	// komentar kode
	// menampilkan pesan hello world
	fmt.Println("hello world")

	// fmt.Println("baris ini tidak akan di eksekusi")
}
