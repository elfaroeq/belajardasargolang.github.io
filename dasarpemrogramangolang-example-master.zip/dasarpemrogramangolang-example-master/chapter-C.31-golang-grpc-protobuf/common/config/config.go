package config

const (
	SERVICE_GARAGE_PORT = ":7000"
	SERVICE_USER_PORT   = ":9000"
)
