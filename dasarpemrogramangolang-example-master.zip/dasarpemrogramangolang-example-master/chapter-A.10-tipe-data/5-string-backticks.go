package main

import "fmt"

func main() {
	var message = `Nama saya "John Wick".
Salam kenal.
Mari belajar "Golang".`

	fmt.Println(message)
}
