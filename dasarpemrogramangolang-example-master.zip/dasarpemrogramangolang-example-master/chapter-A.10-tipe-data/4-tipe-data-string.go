package main

import "fmt"

func main() {
	var message string = "Halo"
	fmt.Printf("message: %s \n", message)
}
