package main

import "fmt"

func main() {
	var exist bool = true
	fmt.Printf("exist? %t \n", exist)
}
