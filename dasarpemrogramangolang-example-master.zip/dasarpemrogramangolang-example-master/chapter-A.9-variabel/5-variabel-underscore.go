package main

import "fmt"

func main() {
	_ = "belajar Golang"
	_ = "Golang itu mudah"
	name, _ := "john", "wick"

	fmt.Println(name)
}
