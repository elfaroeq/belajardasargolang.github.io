package main

import "fmt"

func main() {
	var firstName string = "john"
	lastName := "wick"

	fmt.Printf("halo %s %s!\n", firstName, lastName)
}
